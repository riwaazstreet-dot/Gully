/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialization of Gemini client to prevent crashes if key is missing on startup
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI | null {
  if (aiClient) return aiClient;
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.trim() === "") {
    console.warn("GEMINI_API_KEY is not configured. Running in Local Village Offline Mode with rich pre-canned commentary!");
    return null;
  }
  
  try {
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    return aiClient;
  } catch (error) {
    console.error("Failed to initialize GoogleGenAI client:", error);
    return null;
  }
}

// Fallback canned village commentaries representing classic LBW dramas
const CannedVillageCommentaries = [
  {
    commentary: "Arre Ramesh bhaiya! That ball pitched squarely on a line with the bricks, moved inwards like an agitated cobra, and struck your dirty sandal right in front! That is plumb! No amount of swearing on your cow will save you here. The bowler is dancing and your own team members are secretly laughing.",
    verdictEmoji: "☝️ Plumb OUT!",
    batsmanExcuse: "The ball stayed abnormally low because that brick on the pitch is loose! This delivery is void!",
    umpireVoice: "Batsman, get out! Go and bring the tea now."
  },
  {
    commentary: "What a massive delivery! It pitched outside off-stump, turned like Shane Warne on a dusty village road, but it turned too much! It completely missed the plastic chair we used as stumps and was heading towards the neighbor's mustard farm. The bowler is screaming for LBW but the umpire is calmly eating his samosa.",
    verdictEmoji: "❌ NOT OUT!",
    batsmanExcuse: "I knew it was leaving leg side! I deliberately didn't play a shot to show my superior cricket intelligence.",
    umpireVoice: "That turned more than a cycle tyre! Keep playing, not out."
  },
  {
    commentary: "A roaring yorker! It crashed directly into the wooden stick before you could even bring your heavy bat down! You claim it hit your leg first and was going over, but look at that stick—it's flying! That is as OUT as it gets in gully cricket.",
    verdictEmoji: "🪵 OUT (Bowled / LBW combo)!",
    batsmanExcuse: "There was a chicken running behind the bowler, my concentration was totally shattered!",
    umpireVoice: "Leave the bat here, it is my turn to bat now!"
  },
  {
    commentary: "A beautiful loopy spin. It pitched outside leg-stump! Any village player knows if it pitches outside leg, you cannot be given LBW, even if it strikes your shin on the line! It is the absolute law of the gully turf.",
    verdictEmoji: "❌ NOT OUT (Outside Leg)!",
    batsmanExcuse: "This is basic ICC rule! Bowler doesn't know the rules, he only knows how to run and throw!",
    umpireVoice: "Outside leg bhaiya, even the cow grazing nearby knows that is not out!"
  }
];

// API endpoint for generating funny village LBW commentary
app.post('/api/commentary', async (req, res) => {
  const { 
    stumpType, 
    pitching, 
    impact, 
    wickets, 
    decision, 
    batsmanName = "Ramesh",
    bowlerName = "Suresh"
  } = req.body;

  const client = getGeminiClient();

  if (!client) {
    // Elegant local fallback selector when Gemini API key isn't provided/active
    const idx = Math.floor(Math.random() * CannedVillageCommentaries.length);
    const selected = CannedVillageCommentaries[idx];
    
    // Customize the names slightly to make it interactive even in fallback mode
    const customCommentary = selected.commentary
      .replace(/Ramesh/g, batsmanName)
      .replace(/Ramesh bhaiya/g, `${batsmanName} bhaiya`)
      .replace(/Suresh/g, bowlerName);

    return res.json({
      text: customCommentary,
      verdictEmoji: decision === 'OUT' ? "☝️ PLUMB!" : "❌ SAFE!",
      batsmanExcuse: selected.batsmanExcuse,
      umpireVoice: selected.umpireVoice
    });
  }

  try {
    const prompt = `
      Create a humorous cricket commentary and umpire verdict for a gully/village cricket match LBW dispute.
      In village cricket, there are no real wooden stumps; instead they are playing with a custom object.
      
      MATCH INFOMATION:
      - Custom Stump Object: "${stumpType}" (e.g., pile of bricks, a cardboard box, water can, plastic chair)
      - Batsman Name: "${batsmanName}"
      - Bowler Name: "${bowlerName}"
      - Hawk-Eye Analysis Findings:
        * Ball Pitched: ${pitching}
        * Ball Impact with Leg: ${impact}
        * Ball Directory relative to Wickets: ${wickets}
        * Final Mathematical Verdict: ${decision}
        
      Generate a response strictly in JSON format matching the following schema. Use full local village banter, funny slang (like 'bhaiya', 'arre', 'samosa', 'gully', etc.), and portray the typical high-voltage cricket argument where the batsman makes up a silly excuse to stay on the pitch, and the village umpire (who wants to finish his tea) makes a funny final declaration.

      Response Schema structure:
      {
        "commentary": "Short, energetic, humorous village-commentary paragraph explaining why the batsman is either plumb out or innocent based on the Hawk-Eye data. Playfully taunt the loser.",
        "verdictEmoji": "A funny short verdict string with appropriate emojis (e.g., '🪵 Plumb OUT!', '❌ Not Out - Missing Leg!')",
        "batsmanExcuse": "An absolutely hilarious, typical street cricket excuse that the batsman claims to defend himself.",
        "umpireVoice": "The definitive, funny final dialogue spoken by the local village umpire to resolve the match argument."
      }
    `;

    const response = await client.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            commentary: { type: Type.STRING },
            verdictEmoji: { type: Type.STRING },
            batsmanExcuse: { type: Type.STRING },
            umpireVoice: { type: Type.STRING },
          },
          required: ["commentary", "verdictEmoji", "batsmanExcuse", "umpireVoice"]
        }
      }
    });

    const text = response.text;
    if (text) {
      const parsedData = JSON.parse(text.trim());
      res.json(parsedData);
    } else {
      throw new Error("Empty response from GenAI model");
    }
  } catch (error) {
    console.error("Gemini commentary generation error:", error);
    // Graceful fallback if call errors
    res.json({
      commentary: `Arre! The third umpire's screen broke in the heat, but the trajectory doesn't lie. ${batsmanName} is caught in front off ${bowlerName}'s delivery on the ${stumpType}! Decision is ${decision}.`,
      verdictEmoji: decision === 'OUT' ? "☝️ OUT!" : "❌ NOT OUT!",
      batsmanExcuse: "My bat was blocked by a pebble on the ground!",
      umpireVoice: `I am the owner of the bat and ball, so my decision is final: ${decision}!`
    });
  }
});

// Setup Vite Dev Middleware / Static Assets
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Village Hawk-Eye] Server booted successfully on http://localhost:${PORT}`);
  });
}

startServer();
