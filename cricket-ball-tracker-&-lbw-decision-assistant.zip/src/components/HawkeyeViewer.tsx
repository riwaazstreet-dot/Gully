/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect, useState } from 'react';
import { StumpCalibration, LBWDecision } from '../types';
import { PhysicsTrajectoryPoint } from '../utils/physics';
import { Play, Pause, RotateCcw, VolumeX, Volume2, ShieldCheck, ShieldAlert, Award } from 'lucide-react';
import { synth } from './AudioSynthesizer';

interface HawkeyeViewerProps {
  trajectory: PhysicsTrajectoryPoint[];
  decision: LBWDecision;
  calibration: StumpCalibration;
  stumpType: string;
}

export default function HawkeyeViewer({
  trajectory,
  decision,
  calibration,
  stumpType
}: HawkeyeViewerProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  
  const [isPlaying, setIsPlaying] = useState(true);
  const [playbackProgress, setPlaybackProgress] = useState(0); // 0 to 1
  const [speed, setSpeed] = useState<0.5 | 1 | 2>(1); // Slow-mo support!
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Sound triggers state locks to prevent duplicate sound trigger in loops
  const soundLockedRef = useRef({ bounced: false, hit: false, buzzer: false });

  // Update loop for trajectory playback
  useEffect(() => {
    if (!isPlaying) return;

    let animFrame: number;
    let lastTime = performance.now();

    const updatePlay = (now: number) => {
      const delta = (now - lastTime) / 1000; // seconds
      lastTime = now;

      // Complete path takes 3 seconds in slow mo / normal times speed factors
      const speedFactor = speed === 0.5 ? 0.25 : speed === 1 ? 0.5 : 1.0;
      setPlaybackProgress(prev => {
        const next = prev + delta * speedFactor;
        if (next >= 1) {
          // Re loop simulation smoothly
          soundLockedRef.current = { bounced: false, hit: false, buzzer: false };
          return 0;
        }
        return next;
      });

      animFrame = requestAnimationFrame(updatePlay);
    };

    animFrame = requestAnimationFrame(updatePlay);
    return () => cancelAnimationFrame(animFrame);
  }, [isPlaying, speed]);

  // Handle canvas sizing and continuous frame rendering
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set high-DPI scaling
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const w = rect.width;
    const h = rect.height;

    // Reset sound locks on absolute restart
    if (playbackProgress < 0.05) {
      soundLockedRef.current = { bounced: false, hit: false, buzzer: false };
    }

    // DRAW GROUND & GRASS
    ctx.fillStyle = '#0a2312'; // deep green turf
    ctx.fillRect(0, 0, w, h);

    // Subtle grass blades texturing
    ctx.strokeStyle = '#0e2b16';
    ctx.lineWidth = 1;
    for (let i = 0; i < w; i += 24) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i + (i % 5 - 2) * 2, h);
      ctx.stroke();
    }

    // DRAW PITCH MAT (Perspective bounds)
    // Center-top is narrower, center-bottom is wider
    const topWidth = w * 0.18;
    const bottomWidth = w * 0.65;
    
    const pitchTopLeft = { x: w / 2 - topWidth / 2, y: h * 0.15 };
    const pitchTopRight = { x: w / 2 + topWidth / 2, y: h * 0.15 };
    const pitchBottomLeft = { x: w / 2 - bottomWidth / 2, y: h * 0.9 };
    const pitchBottomRight = { x: w / 2 + bottomWidth / 2, y: h * 0.9 };

    ctx.fillStyle = '#ccb08f'; // baked clay dirt
    ctx.beginPath();
    ctx.moveTo(pitchTopLeft.x, pitchTopLeft.y);
    ctx.lineTo(pitchTopRight.x, pitchTopRight.y);
    ctx.lineTo(pitchBottomRight.x, pitchBottomRight.y);
    ctx.lineTo(pitchBottomLeft.x, pitchBottomLeft.y);
    ctx.closePath();
    ctx.fill();

    // Side grass edges glow
    ctx.strokeStyle = '#22c55e';
    ctx.lineWidth = 2;
    ctx.shadowColor = '#22c55e';
    ctx.shadowBlur = 4;
    ctx.beginPath();
    ctx.moveTo(pitchTopLeft.x, pitchTopLeft.y);
    ctx.lineTo(pitchBottomLeft.x, pitchBottomLeft.y);
    ctx.moveTo(pitchTopRight.x, pitchTopRight.y);
    ctx.lineTo(pitchBottomRight.x, pitchBottomRight.y);
    ctx.stroke();
    ctx.shadowBlur = 0; // reset shadow

    // Crease marking lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
    ctx.lineWidth = 1.5;
    
    // Bowping Crease (top)
    ctx.beginPath();
    ctx.moveTo(w/2 - topWidth * 0.65, h * 0.18);
    ctx.lineTo(w/2 + topWidth * 0.65, h * 0.18);
    ctx.stroke();

    // Batting Crease (bottom)
    ctx.beginPath();
    ctx.moveTo(w/2 - bottomWidth * 0.55, h * 0.84);
    ctx.lineTo(w/2 + bottomWidth * 0.55, h * 0.84);
    ctx.stroke();

    // DRAW CUSTOM CALIBRATED STUMPS (At bottom crease)
    const stumpCenterX = w * (calibration.x / 100);
    const stumpBaseY = h * (calibration.y / 100);
    const stumpW = w * (calibration.width / 100);
    const stumpH = h * (calibration.height / 100);

    // Save context for possible tilt drawing
    ctx.save();
    ctx.translate(stumpCenterX, stumpBaseY);
    ctx.rotate((calibration.tilt * Math.PI) / 180);

    const isCurrentlyOut = decision.decision === 'OUT';

    // Highlight stumps red if ball hit them in playback frame
    // In our calculation, the ball reaches stumps at depth = 20, which is near progress 1
    const ballReachedStumps = playbackProgress > 0.8;
    const stumpsHighlightRed = isCurrentlyOut && ballReachedStumps;

    const renderStumps = () => {
      ctx.shadowBlur = stumpsHighlightRed ? 15 : 0;
      ctx.shadowColor = '#ef4444';

      if (stumpType === 'Pile of Bricks') {
        const numBricks = 6;
        const brickH = stumpH / numBricks;
        
        for (let i = 0; i < numBricks; i++) {
          const currentY = -stumpH + i * brickH;
          // color alternates slightly representing village soil bricks
          ctx.fillStyle = stumpsHighlightRed 
            ? '#ef4444' 
            : i % 2 === 0 ? '#b91c1c' : '#c2410c';
          ctx.strokeStyle = '#450a0a';
          ctx.lineWidth = 1.5;
          ctx.fillRect(-stumpW / 2, currentY, stumpW, brickH - 1);
          ctx.strokeRect(-stumpW / 2, currentY, stumpW, brickH - 1);

          // Draw brick division line
          ctx.strokeStyle = '#78350f';
          ctx.beginPath();
          ctx.moveTo(-stumpW / 6, currentY);
          ctx.lineTo(-stumpW / 6, currentY + brickH - 1);
          ctx.moveTo(stumpW / 4, currentY);
          ctx.lineTo(stumpW / 4, currentY + brickH - 1);
          ctx.stroke();
        }
      } 
      else if (stumpType === 'Wooden Chair') {
        ctx.strokeStyle = stumpsHighlightRed ? '#ef4444' : '#854d0e';
        ctx.lineWidth = 3.5;
        // Chair backrest
        ctx.strokeRect(-stumpW / 2.2, -stumpH, stumpW / 1.1, stumpH / 2.2);
        // Seat
        ctx.fillStyle = stumpsHighlightRed ? '#ef4444' : '#a16207';
        ctx.fillRect(-stumpW / 2, -stumpH / 2, stumpW, 8);
        ctx.strokeRect(-stumpW / 2, -stumpH / 2, stumpW, 8);
        // Chair four legs
        ctx.beginPath();
        ctx.moveTo(-stumpW / 2, -stumpH / 2);
        ctx.lineTo(-stumpW / 2, 0); // front left leg
        ctx.moveTo(stumpW / 2, -stumpH / 2);
        ctx.lineTo(stumpW / 2, 0); // front right leg
        ctx.lineWidth = 2.5;
        ctx.moveTo(-stumpW / 3, -stumpH / 2);
        ctx.lineTo(-stumpW / 3, 4); // back left leg
        ctx.moveTo(stumpW / 3, -stumpH / 2);
        ctx.lineTo(stumpW / 3, 4); // back right leg
        ctx.stroke();
      } 
      else if (stumpType === 'Blue Water Drum') {
        // Red cap
        ctx.fillStyle = stumpsHighlightRed ? '#f87171' : '#dc2626';
        ctx.fillRect(-stumpW / 4, -stumpH, stumpW / 2, 6);
        ctx.strokeRect(-stumpW / 4, -stumpH, stumpW / 2, 6);

        // Core blue body
        const gradient = ctx.createLinearGradient(-stumpW/2, 0, stumpW/2, 0);
        gradient.addColorStop(0, stumpsHighlightRed ? '#450a0a' : '#1e3a8a');
        gradient.addColorStop(0.5, stumpsHighlightRed ? '#ef4444' : '#3b82f6');
        gradient.addColorStop(1, stumpsHighlightRed ? '#7f1d1d' : '#1d4ed8');
        ctx.fillStyle = gradient;
        ctx.strokeStyle = stumpsHighlightRed ? '#f87171' : '#1e40af';
        ctx.lineWidth = 2;
        
        ctx.beginPath();
        // Rounded plastic barrel shape
        ctx.roundRect(-stumpW / 2, -stumpH + 5, stumpW, stumpH - 5, [6, 6, 2, 2]);
        ctx.fill();
        ctx.stroke();

        // Barrel white rings
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(-stumpW / 2, -stumpH * 0.7);
        ctx.lineTo(stumpW / 2, -stumpH * 0.7);
        ctx.moveTo(-stumpW / 2, -stumpH * 0.45);
        ctx.lineTo(stumpW / 2, -stumpH * 0.45);
        ctx.stroke();
      } 
      else {
        // Default classic wooden wickets & bails
        ctx.fillStyle = stumpsHighlightRed ? '#ef4444' : '#b45309';
        ctx.strokeStyle = stumpsHighlightRed ? '#f87171' : '#78350f';
        ctx.lineWidth = 1;
        
        const bailWidth = stumpW / 3;
        // Draw 3 single stumps
        for (let i = 0; i < 3; i++) {
          const sx = -stumpW / 2 + i * (stumpW / 2);
          // wooden post
          ctx.beginPath();
          ctx.roundRect(sx - 3, -stumpH, 6, stumpH, 2);
          ctx.fill();
          ctx.stroke();
        }
        
        // Bails
        ctx.fillRect(-stumpW / 2 - 2, -stumpH - 4, stumpW + 4, 4);
      }
    };

    renderStumps();
    ctx.restore(); // restore from stump position shift/tilt

    // DRAW BALL ROAD & TRAJECTORY PATHS
    const pathCount = trajectory.length;
    if (pathCount < 2) return;

    // Split paths into: before-bounce, after-bounce, predicted-after-impact
    ctx.shadowBlur = 0; // reset
    const visiblePointsCount = Math.floor(playbackProgress * pathCount);

    // Calculate pitching, impact index boundaries for painting trajectory hues
    const pPitch = trajectory.findIndex(p => p.time >= (trajectory[pathCount-1].time * 0.35)); // approximation
    const pImpact = trajectory.findIndex(p => p.time >= (trajectory[pathCount-1].time * 0.65)); // approximation

    // Paint trajectory lines in gorgeous colors
    ctx.lineWidth = 3.5;
    ctx.beginPath();
    
    // Draw past paths
    for (let i = 0; i < visiblePointsCount; i++) {
      const pt = trajectory[i];
      if (i === 0) {
        ctx.moveTo(pt.x2d, pt.y2d);
      } else {
        ctx.lineTo(pt.x2d, pt.y2d);
      }
    }
    
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.85)'; // glowing emerald
    ctx.shadowColor = '#10b981';
    ctx.shadowBlur = 6;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Draw full visual line (as a subtle translucent tracker path overlay in background)
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
    ctx.beginPath();
    trajectory.forEach((tData, i) => {
      if (i === 0) ctx.moveTo(tData.x2d, tData.y2d);
      else ctx.lineTo(tData.x2d, tData.y2d);
    });
    ctx.stroke();

    // Draw future predicted path as pink dashed line once ball goes past the impact point
    const impactPointIndex = Math.floor(pathCount * 0.65);
    if (visiblePointsCount > impactPointIndex) {
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = '#f43f5e'; // neon pink prediction track
      ctx.shadowColor = '#f43f5e';
      ctx.shadowBlur = 6;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      
      const startDrawIndex = Math.max(impactPointIndex, 0);
      for (let i = startDrawIndex; i < visiblePointsCount; i++) {
        if (i === startDrawIndex) {
          ctx.moveTo(trajectory[i].x2d, trajectory[i].y2d);
        } else {
          ctx.lineTo(trajectory[i].x2d, trajectory[i].y2d);
        }
      }
      ctx.stroke();
      ctx.setLineDash([]); // clear dash
      ctx.shadowBlur = 0;
    }

    // DRAW BOUNCE PITCH RING
    const pitchIndex = Math.floor(pathCount * 0.35);
    if (visiblePointsCount >= pitchIndex) {
      const pPt = trajectory[pitchIndex];
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 2.5;
      ctx.shadowColor = '#22c55e';
      ctx.shadowBlur = 8;
      
      ctx.beginPath();
      // Ellipse ring matching flat ground perspective
      ctx.ellipse(pPt.x2d, pPt.y2d, 15, 6, 0, 0, 2 * Math.PI);
      ctx.stroke();
      
      // Paint vertical radar beam
      ctx.strokeStyle = 'rgba(34, 197, 94, 0.2)';
      ctx.beginPath();
      ctx.moveTo(pPt.x2d, pPt.y2d);
      ctx.lineTo(pPt.x2d, pPt.y2d - 60);
      ctx.stroke();
      
      ctx.shadowBlur = 0;

      // Pitching HUD box text overlay on turf
      ctx.font = 'bold 9px monospace';
      ctx.fillStyle = '#10b981';
      ctx.fillText(`PITCHED: ${decision.pitching}`, pPt.x2d + 18, pPt.y2d + 3);

      // Play bounce sound synth
      if (soundEnabled && !soundLockedRef.current.bounced) {
        synth.playBatHit(); // solid contact thud
        soundLockedRef.current.bounced = true;
      }
    }

    // DRAW IMPACT PAD FLAGE/CORNER
    if (visiblePointsCount >= impactPointIndex) {
      const impPt = trajectory[impactPointIndex];
      ctx.strokeStyle = '#f59e0b'; // amber
      ctx.lineWidth = 2.5;
      ctx.shadowColor = '#f59e0b';
      ctx.shadowBlur = 8;

      ctx.beginPath();
      ctx.ellipse(impPt.x2d, impPt.y2d, 12, 5, 0, 0, 2 * Math.PI);
      ctx.stroke();

      ctx.shadowBlur = 0;

      // Draw crosshair at impact
      ctx.strokeStyle = 'rgba(245, 158, 11, 0.4)';
      ctx.beginPath();
      ctx.moveTo(impPt.x2d - 15, impPt.y2d);
      ctx.lineTo(impPt.x2d + 15, impPt.y2d);
      ctx.moveTo(impPt.x2d, impPt.y2d - 15);
      ctx.lineTo(impPt.x2d, impPt.y2d + 15);
      ctx.stroke();

      ctx.font = 'bold 9px monospace';
      ctx.fillStyle = '#f59e0b';
      ctx.fillText(`IMPACT: ${decision.impact}`, impPt.x2d + 15, impPt.y2d + 3);
    }

    // DRAW THE RUNNING CRICKET BALL
    if (visiblePointsCount > 0) {
      const currentBallIndex = Math.min(visiblePointsCount - 1, pathCount - 1);
      const ballPt = trajectory[currentBallIndex];

      // Draw a sleek real-time glowing red-and-white seam rotating leather ball
      const ballRadius = Math.max(3, 4 + (ballPt.y2d / h) * 12); // grows larger as it comes closer to camera perspective!
      
      // Draw ball shadow first
      ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
      ctx.beginPath();
      ctx.ellipse(ballPt.x2d, stumpBaseY, ballRadius, ballRadius / 3, 0, 0, 2 * Math.PI);
      ctx.fill();

      // Draw actual red leather ball
      const ballGradient = ctx.createRadialGradient(
        ballPt.x2d - ballRadius * 0.3,
        ballPt.y2d - ballRadius * 0.3,
        ballRadius * 0.1,
        ballPt.x2d,
        ballPt.y2d,
        ballRadius
      );
      ballGradient.addColorStop(0, '#f87171');
      ballGradient.addColorStop(0.7, '#dc2626');
      ballGradient.addColorStop(1, '#7f1d1d');

      ctx.fillStyle = ballGradient;
      ctx.beginPath();
      ctx.arc(ballPt.x2d, ballPt.y2d, ballRadius, 0, 2 * Math.PI);
      ctx.fill();

      // White ball stitched seam line
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(ballPt.x2d, ballPt.y2d, ballRadius, Math.PI * 0.25 + playbackProgress * 6, Math.PI * 1.25 + playbackProgress * 6);
      ctx.stroke();

      // Draw yellow running sparks trail
      ctx.strokeStyle = 'rgba(245, 158, 11, 0.4)';
      ctx.lineWidth = 1;
      for (let s = 1; s <= 4; s++) {
        const trailIdx = currentBallIndex - s * 3;
        if (trailIdx >= 0) {
          const trailPt = trajectory[trailIdx];
          const trailR = ballRadius * (1 - s * 0.22);
          ctx.beginPath();
          ctx.arc(trailPt.x2d, trailPt.y2d, Math.max(1, trailR), 0, 2 * Math.PI);
          ctx.stroke();
        }
      }

      // If ball hits custom stumps inside playback frame
      const isOutVerdict = decision.decision === 'OUT';
      if (currentBallIndex === pathCount - 1 && isOutVerdict) {
        // Shockwave rings
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.7)';
        ctx.lineWidth = 3;
        ctx.shadowColor = '#ef4444';
        ctx.shadowBlur = 12;
        ctx.beginPath();
        ctx.ellipse(ballPt.x2d, ballPt.y2d, 40, 15, 0, 0, 2 * Math.PI);
        ctx.stroke();
        ctx.shadowBlur = 0;

        // Wood clash sound
        if (soundEnabled && !soundLockedRef.current.hit) {
          synth.playStumpCrash();
          soundLockedRef.current.hit = true;
        }

        // Play umpire buzzer decree
        if (soundEnabled && !soundLockedRef.current.buzzer) {
          synth.playUmpireBuzzer(true);
          soundLockedRef.current.buzzer = true;
        }
      } else if (currentBallIndex === pathCount - 1 && !isOutVerdict) {
        // Safe, pleasant buzzer sound once delivery safe loop completed
        if (soundEnabled && !soundLockedRef.current.buzzer) {
          synth.playUmpireBuzzer(false);
          soundLockedRef.current.buzzer = true;
        }
      }
    }

  }, [trajectory, playbackProgress, calibration, stumpType, soundEnabled]);

  const togglePlayback = () => {
    setIsPlaying(!isPlaying);
  };

  const restartPlayback = () => {
    soundLockedRef.current = { bounced: false, hit: false, buzzer: false };
    setPlaybackProgress(0);
    setIsPlaying(true);
    if (soundEnabled) {
      synth.playLaserSweep();
    }
  };

  return (
    <div className="bg-zinc-900/40 border-2 border-zinc-800 rounded-[2rem] p-6 space-y-6" ref={containerRef}>
      {/* Simulation Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="px-2 py-0.5 text-[9px] font-mono font-black bg-brand/10 border border-brand/25 text-brand rounded uppercase tracking-widest">
            Gully Hawkeye Telemetry v3.5
          </span>
          <h2 className="text-xl font-black uppercase tracking-tight text-white font-display mt-1">3D Trajectory Resolution</h2>
        </div>
        <div className="flex items-center space-x-2">
          {/* Sound toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 rounded-xl bg-zinc-900 border-2 border-zinc-800 text-zinc-400 hover:text-white transition-all"
            title={soundEnabled ? 'Mute Sounds' : 'Enable Sounds'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
          
          {/* Speed settings */}
          <div className="flex items-center bg-zinc-900 border-2 border-zinc-804 rounded-xl overflow-hidden p-0.5">
            <button
              onClick={() => setSpeed(0.5)}
              className={`px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded-lg transition-all ${speed === 0.5 ? 'bg-brand/20 text-brand font-black' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
              0.5x Slow
            </button>
            <button
              onClick={() => setSpeed(1)}
              className={`px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded-lg transition-all ${speed === 1 ? 'bg-brand/20 text-brand font-black' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
              1.0x Real
            </button>
          </div>
        </div>
      </div>

      {/* Visual Canvas and Decides Overlay Stack */}
      <div className="relative aspect-[16/10] w-full rounded-2xl overflow-hidden border-2 border-zinc-800">
        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full block" />

        {/* HUD Stats telemetry bar on left */}
        <div className="absolute top-4 left-4 bg-zinc-950/95 backdrop-blur border-2 border-zinc-800 rounded-2xl p-4 space-y-3 min-w-[170px] select-none">
          <div className="flex items-center space-x-1.5 border-b-2 border-zinc-850 pb-1.5 text-[10px] text-brand font-mono font-bold tracking-widest uppercase">
            <Award className="w-3.5 h-3.5 text-brand" />
            <span>Telemetry</span>
          </div>
          
          <div className="space-y-2">
            <div>
              <div className="text-[9px] text-zinc-500 font-mono uppercase tracking-wider">Pitch Line</div>
              <div className={`text-[11px] font-mono font-black uppercase flex items-center gap-1.5 ${
                decision.pitching === 'In Line' ? 'text-brand' : 'text-rose-500'
              }`}>
                <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
                <span>{decision.pitching}</span>
              </div>
            </div>

            <div>
              <div className="text-[9px] text-zinc-500 font-mono uppercase tracking-wider">Impact Pad</div>
              <div className={`text-[11px] font-mono font-black uppercase flex items-center gap-1.5 ${
                decision.impact === 'In Line' ? 'text-brand' : 'text-amber-500'
              }`}>
                <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
                <span>{decision.impact}</span>
              </div>
            </div>

            <div>
              <div className="text-[9px] text-zinc-500 font-mono uppercase tracking-wider">Stump Path</div>
              <div className={`text-[11px] font-mono font-black uppercase flex items-center gap-1.5 ${
                decision.wickets === 'Hitting' ? 'text-rose-500 animate-pulse' : 'text-brand'
              }`}>
                <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
                <span>{decision.wickets}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Final Decision Stamp flashing */}
        {playbackProgress > 0.75 && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm pointer-events-none select-none">
            <div className={`px-12 py-8 border-4 rounded-[2.5rem] text-center transform scale-110 rotate-[-5deg] transition-all duration-300 ${
              decision.decision === 'OUT' 
              ? 'bg-red-650 border-white text-white shadow-2xl shadow-red-50 animate-bounce' 
              : 'bg-brand border-black text-black shadow-neon animate-pulse'
            }`}>
              <div className="text-[10px] font-mono tracking-[0.3em] font-extrabold uppercase mb-1 opacity-75">AI Decision</div>
              <div className="text-6xl font-display font-black tracking-tighter uppercase leading-none">
                {decision.decision}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Playback controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-t-2 border-zinc-850 pt-5">
        <div className="flex items-center space-x-3 w-full sm:w-auto justify-center sm:justify-start">
          <button
            onClick={togglePlayback}
            className="flex items-center space-x-2 px-5 py-2.5 bg-brand text-zinc-950 rounded-xl font-black uppercase text-xs tracking-wider hover:scale-105 active:scale-95 transition-all shadow-neon cursor-pointer"
          >
            {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
            <span>{isPlaying ? 'Pause Feed' : 'Resume Review'}</span>
          </button>
          
          <button
            onClick={restartPlayback}
            className="flex items-center space-x-1 px-4 py-2.5 bg-zinc-900 border-2 border-zinc-800 text-zinc-300 rounded-xl hover:text-white hover:bg-zinc-800 transition-all text-xs font-black uppercase tracking-wider cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Replay</span>
          </button>
        </div>

        <div className="flex items-center space-x-2 bg-zinc-900/80 border-2 border-zinc-800 px-5 py-3 rounded-2xl text-xs w-full sm:w-auto justify-center">
          {decision.decision === 'OUT' ? (
            <ShieldAlert className="w-4 h-4 text-rose-500 shrink-0 animate-pulse" />
          ) : (
            <ShieldCheck className="w-4 h-4 text-brand shrink-0" />
          )}
          <span className="font-mono text-[10px] font-bold text-zinc-400">
            {decision.summary}
          </span>
        </div>
      </div>
    </div>
  );
}
