/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { StumpCalibration, BallTrackingPoint, LBWDecision, CommentaryResponse } from '../types';
import { VILLAGE_SAMPLES } from '../utils/samples';
import { calculateTrajectoryAndDecision, PhysicsTrajectoryPoint } from '../utils/physics';
import { Camera, Upload, Play, Sliders, Check, CircleAlert, HelpCircle, User, Sparkles } from 'lucide-react';
import HawkeyeViewer from './HawkeyeViewer';
import VillageBanter from './VillageBanter';

export default function TrackingSandbox() {
  // Config state
  const [bowlerName, setBowlerName] = useState('Suresh');
  const [batsmanName, setBatsmanName] = useState('Ramesh');
  const [stumpType, setStumpType] = useState('Pile of Bricks');

  // Interactive samples selector
  const [selectedSampleId, setSelectedSampleId] = useState(VILLAGE_SAMPLES[0].id);

  // Stump Calibration state (percentage scales 0-100 on the viewport)
  const [calibration, setCalibration] = useState<StumpCalibration>(
    VILLAGE_SAMPLES[0].defaultCalibration
  );

  // Ball tracking coordinates (Release, Pitch, Impact points on video box)
  const [trackingPoints, setTrackingPoints] = useState<BallTrackingPoint[]>(
    VILLAGE_SAMPLES[0].defaultTrackingPoints
  );

  // Calculated track output
  const [trajectoryData, setTrajectoryData] = useState<PhysicsTrajectoryPoint[]>([]);
  const [lbwDecision, setLbwDecision] = useState<LBWDecision | null>(null);

  // AI Commentary state
  const [commentary, setCommentary] = useState<CommentaryResponse | null>(null);
  const [commentaryLoading, setCommentaryLoading] = useState(false);

  // Active Camera Stream & Upload files states
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [uploadedVideoUrl, setUploadedVideoUrl] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const mediaContainerRef = useRef<HTMLDivElement | null>(null);

  // Drag-and-drop tracking point indices
  const [activeDragPointId, setActiveDragPointId] = useState<string | null>(null);

  // Ref for manual upload input
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Trigger recalculations on tracking points or stump calibration shifts
  useEffect(() => {
    const { trajectory, decision } = calculateTrajectoryAndDecision(calibration, trackingPoints);
    setTrajectoryData(trajectory);
    setLbwDecision(decision);
  }, [calibration, trackingPoints]);

  // Handle preset sample changes
  const handleSampleSelect = (sampleId: string) => {
    const s = VILLAGE_SAMPLES.find(x => x.id === sampleId);
    if (!s) return;
    
    setSelectedSampleId(sampleId);
    setCalibration(s.defaultCalibration);
    setTrackingPoints(s.defaultTrackingPoints);
    setStumpType(s.stumpType);
    
    // Parse bowler/batsman names from description
    if (sampleId === 'sample_bricks_yorker') {
      setBowlerName('Suresh');
      setBatsmanName('Ramesh');
    } else if (sampleId === 'sample_chair_turner') {
      setBowlerName('Dinesh');
      setBatsmanName('Mukesh');
    } else if (sampleId === 'sample_water_jug_bouncer') {
      setBowlerName('Anish');
      setBatsmanName('Umesh');
    } else if (sampleId === 'sample_stick_swing') {
      setBowlerName('Mahesh');
      setBatsmanName('Ganesh');
    }

    // Stop active camera
    stopCamera();
    setUploadedVideoUrl(null);
    setCommentary(null);
  };

  // Start real-time webcam feed
  const startCamera = async () => {
    try {
      setUploadedVideoUrl(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 640 }, height: { ideal: 480 } }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setIsCameraActive(true);
      // Setup logical default points when starting webcam scene
      setTrackingPoints([
        { id: 'p1', x: 50, y: 22, frameIndex: 1, type: 'release', label: 'Release' },
        { id: 'p2', x: 49, y: 68, frameIndex: 2, type: 'pitch', label: 'Pitching' },
        { id: 'p3', x: 48, y: 76, frameIndex: 3, type: 'impact', label: 'Impact (Pad)' },
      ]);
    } catch (e) {
      console.error("Camera access failed:", e);
      alert("Failed to start web camera. Make sure permissions are allowed, or continue playing with our pre-set matches!");
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
    streamRef.current = null;
    setIsCameraActive(false);
  };

  // Local physical video parsing
  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    stopCamera();
    const url = URL.createObjectURL(file);
    setUploadedVideoUrl(url);
    
    // Reset points
    setTrackingPoints([
      { id: 'p1', x: 50, y: 22, frameIndex: 1, type: 'release', label: 'Release' },
      { id: 'p2', x: 50, y: 70, frameIndex: 2, type: 'pitch', label: 'Pitching' },
      { id: 'p3', x: 50, y: 78, frameIndex: 3, type: 'impact', label: 'Impact (Pad)' },
    ]);
  };

  // Draggable telemetry anchor pins handler
  const handlePointMouseDown = (id: string) => {
    setActiveDragPointId(id);
  };

  const handlePointDrag = (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
    if (!activeDragPointId || !mediaContainerRef.current) return;

    const rect = mediaContainerRef.current.getBoundingClientRect();
    let posX = 0;
    let posY = 0;

    if ('touches' in e) {
      if (e.touches.length === 0) return;
      posX = e.touches[0].clientX - rect.left;
      posY = e.touches[0].clientY - rect.top;
    } else {
      posX = e.clientX - rect.left;
      posY = e.clientY - rect.top;
    }

    // percentage coordinates matching video scales boundaries
    const pctX = Math.min(Math.max((posX / rect.width) * 100, 0), 100);
    const pctY = Math.min(Math.max((posY / rect.height) * 100, 0), 100);

    setTrackingPoints(prev =>
      prev.map(p => (p.id === activeDragPointId ? { ...p, x: parseFloat(pctX.toFixed(2)), y: parseFloat(pctY.toFixed(2)) } : p))
    );
  };

  const handlePointMouseUp = () => {
    setActiveDragPointId(null);
  };

  // Invoke server API route to query Gemini commentator
  const triggerResolveCommentary = async () => {
    if (!lbwDecision) return;

    setCommentaryLoading(true);
    try {
      const response = await fetch('/api/commentary', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          stumpType,
          pitching: lbwDecision.pitching,
          impact: lbwDecision.impact,
          wickets: lbwDecision.wickets,
          decision: lbwDecision.decision,
          batsmanName,
          bowlerName
        })
      });

      const data = await response.json();
      setCommentary(data);
    } catch (err) {
      console.error("Failed to query commentary service:", err);
    } finally {
      setCommentaryLoading(false);
    }
  };

  return (
    <div className="space-y-8" onMouseMove={handlePointDrag} onTouchMove={handlePointDrag} onMouseUp={handlePointMouseUp} onTouchEnd={handlePointMouseUp}>
      {/* Sandbox Workspace grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COLUMN: Media calibration console */}
        <div className="col-span-1 lg:col-span-8 space-y-6">
          <div className="bg-zinc-900/40 border-2 border-zinc-800 rounded-[2rem] p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-black uppercase tracking-tight text-white font-display">Calibration Desk</h2>
                <p className="text-[11px] font-mono text-zinc-500 mt-0.5 uppercase tracking-wide">Calibrate coordinates & stumps manually</p>
              </div>

              {/* Media selection controls */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={startCamera}
                  className={`flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl border-2 text-xs font-black uppercase tracking-wider cursor-pointer transition-all ${
                    isCameraActive 
                    ? 'bg-brand/20 border-brand text-brand shadow-neon' 
                    : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800/80'
                  }`}
                >
                  <Camera className="w-4 h-4" />
                  <span>Use Camera</span>
                </button>

                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center space-x-1.5 px-3.5 py-1.5 bg-zinc-900 hover:bg-zinc-800 border-2 border-zinc-805 text-zinc-300 rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer transition-all"
                >
                  <Upload className="w-4 h-4" />
                  <span>Upload Video</span>
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="video/*"
                  onChange={handleVideoUpload}
                  className="hidden"
                />
              </div>
            </div>

            {/* Media Screen Box container */}
            <div
              ref={mediaContainerRef}
              className="relative aspect-[16/10] w-full rounded-2xl overflow-hidden bg-zinc-900/60 border border-zinc-850 select-none cursor-crosshairs shadow-inner block"
            >
              {/* Backing rendering options */}
              {isCameraActive ? (
                <video
                  ref={videoRef}
                  className="absolute inset-0 w-full h-full object-cover pointer-events-none scale-x-[-1]"
                  playsInline
                  muted
                />
              ) : uploadedVideoUrl ? (
                <video
                  src={uploadedVideoUrl}
                  className="absolute inset-0 w-full h-full object-cover pointer-events-none"
                  playsInline
                  loop
                  autoPlay
                  muted
                />
              ) : (
                // Simulated Village Cam filter with beautiful drawing sequence!
                <div className="absolute inset-0 w-full h-full overflow-hidden flex items-center justify-center bg-zinc-900">
                  {/* Decorative village retro graphics */}
                  <div className="absolute top-4 left-4 flex items-center space-x-2 bg-black/60 px-3 py-1.5 rounded-lg border border-red-500/30 text-[10px] text-red-400 font-mono tracking-wider">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>
                    <span>REC FEED</span>
                  </div>
                  
                  {/* Beautiful visual background showing rustic pitch under shade */}
                  <div className="text-center space-y-1 z-10 p-5 bg-zinc-950/40 backdrop-blur-sm rounded-2xl border border-zinc-800 max-w-sm">
                    <p className="text-xs font-mono text-emerald-400">⚡ Preset: {VILLAGE_SAMPLES.find(x => x.id === selectedSampleId)?.name}</p>
                    <p className="text-xs text-zinc-400 font-sans font-light mt-1">
                      {VILLAGE_SAMPLES.find(x => x.id === selectedSampleId)?.description}
                    </p>
                  </div>

                  {/* Retro VHS visual grid layout lines */}
                  <div className="absolute inset-0 border border-white/5 grid grid-cols-3 grid-rows-3 pointer-events-none">
                    <div className="border-r border-b border-white/2 pointer-events-none"></div>
                    <div className="border-r border-b border-white/2 pointer-events-none"></div>
                    <div className="border-b border-white/2 pointer-events-none"></div>
                    <div className="border-r border-b border-white/2 pointer-events-none"></div>
                    <div className="border-r border-b border-white/2 pointer-events-none"></div>
                    <div className="border-b border-white/2 pointer-events-none"></div>
                    <div className="border-r border-white/2 pointer-events-none"></div>
                    <div className="border-r border-white/2 pointer-events-none"></div>
                  </div>
                </div>
              )}

              {/* OVERLAY 1: Custom Calibrated Stumps (dashed wireframe boundary representing calibrated stakes position) */}
              <div
                style={{
                  left: `${calibration.x - calibration.width / 2}%`,
                  bottom: `${100 - calibration.y}%`, // relative to ground line
                  width: `${calibration.width}%`,
                  height: `${calibration.height}%`,
                  transform: `rotate(${calibration.tilt}deg)`,
                  transformOrigin: 'bottom center'
                }}
                className="absolute border-2 border-dashed border-brand bg-brand/10 rounded backdrop-blur-xs flex items-center justify-center transition-all"
              >
                <div className="px-2 py-1 bg-zinc-950 text-brand text-[8px] font-mono font-bold uppercase tracking-widest rounded border border-brand/35">
                  STUMPS ACTIVE
                </div>
              </div>

              {/* OVERLAY 2: Draggable Telemetry Anchor Pins (Release, Pitch, Impact coordinates) */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none">
                {/* Reconstruct visual connecting Bezier lines */}
                {trackingPoints.length >= 3 && (
                  <path
                    d={`M ${trackingPoints[0].x}% ${trackingPoints[0].y}% Q ${trackingPoints[1].x}% ${trackingPoints[1].y}% ${trackingPoints[2].x}% ${trackingPoints[2].y}%`}
                    fill="none"
                    stroke="rgba(255, 255, 255, 0.4)"
                    strokeWidth="3"
                    strokeDasharray="4, 4"
                    pathLength="100"
                  />
                )}
              </svg>

              {trackingPoints.map((p, idx) => (
                <div
                  key={p.id}
                  style={{ left: `${p.x}%`, top: `${p.y}%` }}
                  onMouseDown={() => handlePointMouseDown(p.id)}
                  onTouchStart={() => handlePointMouseDown(p.id)}
                  className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center space-y-1 z-20 cursor-grab active:cursor-grabbing group"
                >
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center text-[10px] font-bold shadow-lg shadow-black/80 ring-4 transition-all ${
                    idx === 0 
                      ? 'bg-cyan-500 border-white text-zinc-950 ring-cyan-500/25 group-hover:scale-125' 
                      : idx === 1 
                        ? 'bg-amber-500 border-white text-zinc-950 ring-amber-500/25 group-hover:scale-125' 
                        : 'bg-rose-500 border-white text-zinc-950 ring-rose-500/25 group-hover:scale-125'
                  }`}>
                    {idx === 0 ? 'A' : idx === 1 ? 'B' : 'C'}
                  </div>
                  
                  {/* Label overlay below point pin */}
                  <span className="bg-zinc-950/90 border border-zinc-800 text-[8px] font-mono text-zinc-300 font-semibold px-1.5 py-0.5 rounded shadow whitespace-nowrap opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
                    {p.label}
                  </span>
                </div>
              ))}
            </div>

            {/* Instruction Tip */}
            <div className="flex items-start space-x-3 bg-zinc-900/40 p-4 rounded-2xl border-2 border-zinc-850/60">
              <HelpCircle className="w-5 h-5 text-brand shrink-0 mt-0.5" />
              <div className="text-xs text-zinc-400 leading-relaxed font-sans">
                💡 <span className="font-extrabold text-zinc-200 uppercase tracking-widest text-[10px] font-mono">Referee Guidelines:</span> Drag point <span className="text-cyan-300 font-bold font-mono">A</span> to ball delivery release, point <span className="text-amber-300 font-bold font-mono">B</span> to surface landing, and point <span className="text-rose-400 font-bold font-mono">C</span> to battery impact point. Stumpless tracking updates autonomously.
              </div>
            </div>
          </div>

          {/* TRAJECTORY RESOLVER STAGE */}
          {trajectoryData.length > 0 && lbwDecision && (
            <HawkeyeViewer
              trajectory={trajectoryData}
              decision={lbwDecision}
              calibration={calibration}
              stumpType={stumpType}
            />
          )}

          {/* AI DECISION BANTER BOARD */}
          <div className="bg-zinc-900/40 border-2 border-zinc-800 rounded-[2rem] p-6 space-y-5">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b-2 border-zinc-850 pb-4">
              <div>
                <h3 className="text-base font-black uppercase tracking-tight text-white font-display">AI Third Umpire Commentary</h3>
                <p className="text-xs text-zinc-500 font-light font-sans mt-0.5">Let the neural commentary settle street arguments without a physical brawl!</p>
              </div>
              <button
                onClick={triggerResolveCommentary}
                disabled={commentaryLoading}
                className="w-full sm:w-auto flex items-center justify-center space-x-2 px-6 py-3 bg-brand disabled:opacity-50 text-black rounded-xl text-xs font-black uppercase tracking-wider select-none cursor-pointer active:scale-95 transition-all shadow-neon"
              >
                <Sparkles className="w-4 h-4 animate-spin-slow" />
                <span>Resolve LBW Argument!</span>
              </button>
            </div>

            <VillageBanter
              commentary={commentary}
              loading={commentaryLoading}
              batsmanName={batsmanName}
              bowlerName={bowlerName}
              stumpType={stumpType}
              decision={lbwDecision?.decision || 'NOT OUT'}
            />
          </div>
        </div>

        {/* RIGHT COLUMN: Config parameters & calibrations sliders */}
        <div className="col-span-1 lg:col-span-4 space-y-6">
          {/* Gully Match Details form */}
          <div className="bg-zinc-900/40 border-2 border-zinc-800 rounded-[2rem] p-6 space-y-5">
            <div className="flex items-center space-x-2 text-xs text-brand font-mono font-black tracking-widest uppercase border-b-2 border-zinc-850 pb-3">
              <User className="w-4 h-4 text-brand" />
              <span>MATCH PARTICIPANTS</span>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="text-[10px] text-zinc-400 font-mono font-black uppercase tracking-wide">Striker Batsman</label>
                <input
                  type="text"
                  value={batsmanName}
                  onChange={e => setBatsmanName(e.target.value)}
                  className="w-full text-xs py-2.5 px-3.5 bg-zinc-950 border-2 border-zinc-800 rounded-xl text-white font-mono font-bold focus:outline-none focus:border-brand mt-1"
                  placeholder="Batsman name (e.g., Ramesh)"
                />
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 font-mono font-black uppercase tracking-wide">Bowler</label>
                <input
                  type="text"
                  value={bowlerName}
                  onChange={e => setBowlerName(e.target.value)}
                  className="w-full text-xs py-2.5 px-3.5 bg-zinc-950 border-2 border-zinc-800 rounded-xl text-white font-mono font-bold focus:outline-none focus:border-brand mt-1"
                  placeholder="Bowler name (e.g., Suresh)"
                />
              </div>
            </div>
          </div>

          {/* Preconfigured Match Practice selections */}
          <div className="bg-zinc-900/40 border-2 border-zinc-800 rounded-[2rem] p-6 space-y-4">
            <div className="flex items-center space-x-2 text-xs text-brand font-mono font-black tracking-widest uppercase border-b-2 border-zinc-850 pb-3">
              <Play className="w-3.5 h-3.5 text-brand fill-current" />
              <span>PRESET MATCH ARCHIVES</span>
            </div>
            
            <div className="flex flex-col space-y-2.5 bg-transparent">
              {VILLAGE_SAMPLES.map(sample => {
                const isSelected = selectedSampleId === sample.id && !isCameraActive && !uploadedVideoUrl;
                return (
                  <button
                    key={sample.id}
                    onClick={() => handleSampleSelect(sample.id)}
                    className={`text-left p-4 rounded-xl border-2 text-xs cursor-pointer transition-all flex flex-col space-y-2 ${
                      isSelected 
                      ? 'bg-brand text-black border-brand shadow-neon' 
                      : 'bg-zinc-950/70 hover:bg-zinc-900 border-zinc-850 text-zinc-300'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className={`font-mono text-xs font-black uppercase ${isSelected ? 'text-black' : 'text-zinc-200'}`}>
                        {sample.name}
                      </span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-black block shrink-0" />}
                    </div>
                    <span className={`text-[10px] font-sans font-light line-clamp-2 ${isSelected ? 'text-black/80' : 'text-zinc-400'}`}>
                      {sample.description}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Custom Stump Calibrator sliders (Select ANY object as stump!) */}
          <div className="bg-zinc-900/40 border-2 border-zinc-800 rounded-[2rem] p-6 space-y-5">
            <div className="flex items-center justify-between border-b-2 border-zinc-850 pb-3">
              <div className="flex items-center space-x-2 text-xs text-brand font-mono font-black tracking-widest uppercase">
                <Sliders className="w-4 h-4 text-brand" />
                <span>STUMP CALIBRATION</span>
              </div>
            </div>

            <div className="space-y-4">
              {/* Select ANY custom stump object */}
              <div>
                <label className="text-[10px] text-zinc-400 font-mono font-black uppercase tracking-wide">Choose Stump Object</label>
                <select
                  value={stumpType}
                  onChange={e => setStumpType(e.target.value)}
                  className="w-full text-xs py-2.5 px-3 bg-zinc-950 border-2 border-zinc-800 rounded-xl text-white font-mono font-bold focus:outline-none focus:border-brand mt-1 cursor-pointer uppercase tracking-wider"
                >
                  <option value="Pile of Bricks">🧱 Pile of Bricks</option>
                  <option value="Wooden Chair">🪑 Wooden Chair</option>
                  <option value="Blue Water Drum">🛢️ Blue Water Drum</option>
                  <option value="Single Stuck Stick">🪵 Single stuck stick</option>
                  <option value="Standard Wooden Wickets">🏏 Standard Wooden Wickets</option>
                </select>
              </div>

              {/* Sliders overlay adjustment */}
              <div className="space-y-4 pt-4 border-t-2 border-zinc-850">
                <div>
                  <div className="flex justify-between items-center text-[10px] text-zinc-400 font-mono font-black uppercase">
                    <span>X Position</span>
                    <span className="text-brand font-bold">{calibration.x}%</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="90"
                    step="0.5"
                    value={calibration.x}
                    onChange={e => setCalibration({ ...calibration, x: parseFloat(e.target.value) })}
                    className="w-full accent-brand cursor-ew-resize bg-zinc-950 rounded-lg h-1.5 border-none mt-1"
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center text-[10px] text-zinc-400 font-mono font-black uppercase">
                    <span>Base Y (Ground Line)</span>
                    <span className="text-brand font-bold">{calibration.y}%</span>
                  </div>
                  <input
                    type="range"
                    min="50"
                    max="95"
                    step="0.5"
                    value={calibration.y}
                    onChange={e => setCalibration({ ...calibration, y: parseFloat(e.target.value) })}
                    className="w-full accent-brand cursor-ew-resize bg-zinc-950 rounded-lg h-1.5 border-none mt-1"
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center text-[10px] text-zinc-400 font-mono font-black uppercase">
                    <span>Width</span>
                    <span className="text-brand font-bold">{calibration.width}%</span>
                  </div>
                  <input
                    type="range"
                    min="4"
                    max="30"
                    step="0.5"
                    value={calibration.width}
                    onChange={e => setCalibration({ ...calibration, width: parseFloat(e.target.value) })}
                    className="w-full accent-brand cursor-ew-resize bg-zinc-950 rounded-lg h-1.5 border-none mt-1"
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center text-[10px] text-zinc-400 font-mono font-black uppercase">
                    <span>Height</span>
                    <span className="text-brand font-bold">{calibration.height}%</span>
                  </div>
                  <input
                    type="range"
                    min="15"
                    max="60"
                    step="0.5"
                    value={calibration.height}
                    onChange={e => setCalibration({ ...calibration, height: parseFloat(e.target.value) })}
                    className="w-full accent-brand cursor-ew-resize bg-zinc-950 rounded-lg h-1.5 border-none mt-1"
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center text-[10px] text-zinc-400 font-mono font-black uppercase">
                    <span>Stump Tilt / Slant</span>
                    <span className="text-brand font-bold">{calibration.tilt}°</span>
                  </div>
                  <input
                    type="range"
                    min="-15"
                    max="15"
                    step="0.5"
                    value={calibration.tilt}
                    onChange={e => setCalibration({ ...calibration, tilt: parseFloat(e.target.value) })}
                    className="w-full accent-brand cursor-ew-resize bg-zinc-950 rounded-lg h-1.5 border-none mt-1"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
