/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CommentaryResponse } from '../types';
import { Volume2, ShieldAlert, Award, MessageCircle, AlertCircle, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface VillageBanterProps {
  commentary: CommentaryResponse | null;
  loading: boolean;
  batsmanName: string;
  bowlerName: string;
  stumpType: string;
  decision: 'OUT' | 'NOT OUT';
}

export default function VillageBanter({
  commentary,
  loading,
  batsmanName,
  bowlerName,
  stumpType,
  decision
}: VillageBanterProps) {
  const [isSpeaking, setIsSpeaking] = useState(false);

  const speakAloud = () => {
    if (!commentary || typeof window === 'undefined') return;
    
    // Stop any ongoing speech
    window.speechSynthesis.cancel();
    setIsSpeaking(true);

    const fullDialogue = `
      Umpire says: ${commentary.umpireVoice}.
      The batsman ${batsmanName} excuses: ${commentary.batsmanExcuse}.
      Commentator breakdown: ${commentary.text}
    `;

    const utterance = new SpeechSynthesisUtterance(fullDialogue);
    utterance.rate = 1.05;
    utterance.volume = 1;
    // Try to find a warm/dramatic English voice or default
    const voices = window.speechSynthesis.getVoices();
    const descriptiveVoice = voices.find(v => v.lang.includes('en-IN') || v.lang.includes('en-GB')) || voices[0];
    if (descriptiveVoice) {
      utterance.voice = descriptiveVoice;
    }

    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  if (loading) {
    return (
      <div className="bg-zinc-900/60 border-2 border-zinc-850 rounded-[2rem] p-8 flex flex-col items-center justify-center text-center space-y-4">
        <div className="relative">
          <div className="w-12 h-12 border-4 border-brand/20 border-t-brand rounded-full animate-spin"></div>
          <Sparkles className="absolute -top-1 -right-1 text-brand w-5 h-5 animate-pulse" />
        </div>
        <div className="space-y-1">
          <h4 className="text-sm font-black text-brand font-mono tracking-widest uppercase">SUMMONING COURT COUNCIL...</h4>
          <p className="text-xs text-zinc-400 font-sans">Arbitrating parameters & consulting gully cricket bylaws</p>
        </div>
      </div>
    );
  }

  if (!commentary) {
    return (
      <div className="bg-zinc-900/20 border-2 border-dashed border-zinc-800 rounded-[2rem] p-8 text-center space-y-2">
        <AlertCircle className="w-8 h-8 text-zinc-650 mx-auto" />
        <p className="text-xs text-zinc-500 font-mono uppercase tracking-wider">Awaiting dynamic deliveries to invoke live commentating.</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-6"
    >
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-2">
          <MessageCircle className="w-5 h-5 text-brand animate-pulse" />
          <h3 className="text-lg font-black uppercase tracking-tight text-white font-display">COUNCIL DECREE & BANTER</h3>
        </div>
        <button
          onClick={speakAloud}
          disabled={isSpeaking}
          className={`flex items-center space-x-1.5 px-4 py-2 text-xs rounded-xl border-2 font-black uppercase tracking-wider transition-all cursor-pointer ${
            isSpeaking 
            ? 'bg-brand/20 border-brand text-brand animate-pulse' 
            : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white'
          }`}
        >
          <Volume2 className="w-4 h-4" />
          <span>{isSpeaking ? 'Speaking...' : 'Verbal Verdict'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Batsman's Excuses */}
        <div className="bg-[#121212] border-2 border-zinc-800 rounded-2xl p-5 space-y-3 relative overflow-hidden flex flex-col justify-between">
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <span className="w-2 rounded-full aspect-square bg-rose-500"></span>
              <h4 className="text-[10px] font-mono font-black text-rose-400 uppercase tracking-widest">BATSMAN ({batsmanName})</h4>
            </div>
            <p className="text-xs font-sans italic text-zinc-300 leading-relaxed font-semibold">
              &ldquo;{commentary.batsmanExcuse}&rdquo;
            </p>
          </div>
          <div className="text-[9px] font-mono font-bold uppercase text-rose-500 mt-2">
            Status: Aggravated street claim
          </div>
        </div>

        {/* AI Umpire's Decree */}
        <div className={`border-2 rounded-2xl p-5 space-y-3 relative overflow-hidden flex flex-col justify-between ${
          decision === 'OUT' 
          ? 'bg-rose-950/20 border-rose-500 shadow-neon' 
          : 'bg-brand/10 border-brand text-white shadow-neon'
        }`}>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <ShieldAlert className={`w-4 h-4 ${decision === 'OUT' ? 'text-rose-400' : 'text-brand'}`} />
              <h4 className="text-[10px] font-mono font-black text-zinc-400 uppercase tracking-widest">OFFICIAL RULING</h4>
            </div>
            <p className="text-xs font-sans font-black text-white leading-relaxed">
              &ldquo;{commentary.umpireVoice}&rdquo;
            </p>
          </div>
          <div className={`text-sm font-black uppercase tracking-wider mt-2 flex items-center gap-1.5 ${
            decision === 'OUT' ? 'text-rose-400' : 'text-brand'
          }`}>
            <span>Verdict: {commentary.verdictEmoji}</span>
          </div>
        </div>

        {/* Bowler's Reaction */}
        <div className="bg-[#121212] border-2 border-zinc-800 rounded-2xl p-5 space-y-3 relative overflow-hidden flex flex-col justify-between">
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <span className="w-2 rounded-full aspect-square bg-brand"></span>
              <h4 className="text-[10px] font-mono font-black text-brand uppercase tracking-widest">BOWLER CLAIM ({bowlerName})</h4>
            </div>
            <p className="text-xs font-sans italic text-zinc-300 leading-relaxed font-semibold">
              {decision === 'OUT' 
                ? `\"Abbe match khatam, Ramesh! Clean wicket on the ${stumpType.toLowerCase()}! Pack your kit and fetch my cycle keys!\"`
                : `\"Arre yaar, that was heading straight for off-stump! Let's check the frame again, next down you are completely gone!\"`
              }
            </p>
          </div>
          <div className="text-[9px] font-mono font-bold uppercase text-brand mt-2">
            Status: {decision === 'OUT' ? 'Victory lap underway' : 'Appealing for lbw again'}
          </div>
        </div>
      </div>

      {/* Broadcast Commentary Breakdown */}
      <div className="bg-brand/10 border-2 border-brand/20 rounded-2xl p-5 space-y-2">
        <div className="flex items-center space-x-1.5 text-[10px] text-brand font-mono font-black uppercase tracking-widest">
          <Award className="w-4 h-4" />
          <span>Live Broadcaster Commentary</span>
        </div>
        <p className="text-xs text-zinc-100 leading-relaxed font-sans font-medium">
          {commentary.text}
        </p>
      </div>
    </motion.div>
  );
}
