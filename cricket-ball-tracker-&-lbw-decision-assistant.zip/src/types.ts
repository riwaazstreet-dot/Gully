/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Point2D {
  x: number;
  y: number;
}

export interface StumpCalibration {
  // Coordinates are normalized percentages (0 to 100) relative to the video viewport
  x: number; // center x of stumps base
  y: number; // base y of stumps (ground line)
  width: number; // width of the custom stump boundary
  height: number; // height of the custom stump boundary
  tilt: number; // tilt in degrees (default 0)
}

export type PointType = 'release' | 'pitch' | 'impact';

export interface BallTrackingPoint {
  id: string;
  x: number; // percentage width (0-100)
  y: number; // percentage height (0-100)
  frameIndex: number;
  type: PointType;
  label: string;
}

export interface ProjectorParams {
  gravity: number;
  bounceLoss: number;
  seamDeviation: number; // lateral movement off the pitch
}

export interface LBWDecision {
  pitching: 'In Line' | 'Outside Off' | 'Outside Leg' | 'Not Pitched';
  impact: 'In Line' | 'Outside' | 'Missing Wickets';
  wickets: 'Hitting' | 'Missing' | 'Umpire\'s Call';
  decision: 'OUT' | 'NOT OUT';
  summary: string;
  details: {
    pitchingLine: string;
    impactLine: string;
    wicketContact: string;
    ballHeightAtWickets: number; // normalized units
    stumpTopHeight: number;
  };
}

export interface DeliverySample {
  id: string;
  name: string;
  description: string;
  videoUrl?: string; // fallback placeholder or elegant generated canvas sequence
  stumpType: string; // e.g., 'Pile of Bricks', 'Wooden Chair', 'Plastic Drum', 'Spotted Tree'
  defaultCalibration: StumpCalibration;
  defaultTrackingPoints: BallTrackingPoint[];
  narrative: string;
}

export interface CommentaryResponse {
  text: string;
  audioUrl?: string;
  verdictEmoji: string;
  batsmanExcuse: string;
  umpireVoice: string;
}
