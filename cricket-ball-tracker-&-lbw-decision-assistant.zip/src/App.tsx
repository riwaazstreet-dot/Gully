/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import TrackingSandbox from './components/TrackingSandbox';
import { Target, HelpCircle, Shield, Sparkles, BookOpen, Volume2 } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'tracker' | 'rules'>('tracker');

  return (
    <div className="min-h-screen bg-[#121212] text-zinc-100 flex flex-col font-sans selection:bg-brand/30 selection:text-white">
      {/* Immersive Stadium Top Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-48 bg-gradient-to-b from-brand/15 via-transparent to-transparent blur-3xl pointer-events-none"></div>

      {/* Main Container */}
      <div className="max-w-7xl w-full mx-auto px-4 sm:px-8 py-8 flex-grow flex flex-col space-y-8 relative z-10">
        
        {/* Masthead Header */}
        <header className="flex flex-col md:flex-row items-start md:items-end justify-between border-b-2 border-zinc-800 pb-6 gap-6">
          <div className="space-y-1">
            <h1 className="text-5xl sm:text-7xl font-black leading-none tracking-tighter uppercase font-display select-none">
              STUMPLESS<span className="text-brand">.</span>
            </h1>
            <p className="text-[10px] sm:text-xs tracking-[0.34em] font-bold opacity-50 uppercase mt-2 font-mono">
              Autonomous Village Ball-Tracking System v3.5 & DRS
            </p>
          </div>

          {/* Navigation Controls */}
          <div className="flex bg-zinc-900/80 border-2 border-zinc-805 rounded-xl p-1 w-full md:w-auto">
            <button
              onClick={() => setActiveTab('tracker')}
              className={`flex-1 md:flex-initial flex items-center justify-center space-x-1.5 px-5 py-2 rounded-lg text-xs font-black uppercase tracking-wider cursor-pointer transition-all ${
                activeTab === 'tracker' 
                ? 'bg-brand text-black font-extrabold shadow-neon' 
                : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Hawk-Eye Desk</span>
            </button>
            <button
              onClick={() => setActiveTab('rules')}
              className={`flex-1 md:flex-initial flex items-center justify-center space-x-1.5 px-5 py-2 rounded-lg text-xs font-black uppercase tracking-wider cursor-pointer transition-all ${
                activeTab === 'rules' 
                ? 'bg-brand text-black font-extrabold shadow-neon' 
                : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Gully Bylaws</span>
            </button>
          </div>
        </header>

        {/* Dynamic Display Router content */}
        <main className="flex-grow">
          {activeTab === 'tracker' ? (
            <TrackingSandbox />
          ) : (
            <div className="max-w-3xl mx-auto py-4 space-y-6">
              
              {/* Bylaws Card */}
              <div className="bg-zinc-900/60 border-2 border-zinc-800 rounded-[2rem] p-8 space-y-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-brand/5 to-transparent blur-2xl pointer-events-none"></div>
                
                <div className="flex items-center space-x-2.5 border-b-2 border-zinc-800 pb-4">
                  <Shield className="w-6 h-6 text-brand" />
                  <h2 className="text-2xl font-black uppercase tracking-tight font-display text-white">Official Street Cricket Bylaws</h2>
                </div>

                <div className="space-y-4 text-sm text-zinc-300 leading-relaxed font-sans">
                  <p>
                    Because street and village matches operate on unique, sacred principles not found in Lord&apos;s or the MCG, the Gully Hawkeye systems strictly honors the local village bylaws to maintain harmony (and prevent fistfights):
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3">
                    <div className="bg-zinc-900/40 border-2 border-zinc-800 p-5 rounded-2xl space-y-1.5">
                      <div className="text-xs font-mono font-black text-brand uppercase tracking-widest">Bylaw #1</div>
                      <h4 className="text-sm font-black text-zinc-100 uppercase tracking-tight family-display">The Pitching Outside Leg Safeguard</h4>
                      <p className="text-xs text-zinc-400 leading-relaxed">
                        If the ball pitches outside the batsman&apos;s leg-stump boundary on the dirt, the LBW appeal is immediately declared void. You cannot appeal for LBW on leg-side pitches even if it hits the shin plumb.
                      </p>
                    </div>

                    <div className="bg-zinc-900/40 border-2 border-zinc-800 p-5 rounded-2xl space-y-1.5">
                      <div className="text-xs font-mono font-black text-brand uppercase tracking-widest">Bylaw #2</div>
                      <h4 className="text-sm font-black text-zinc-100 uppercase tracking-tight family-display">Roof tiles & Window Panes Violation</h4>
                      <p className="text-xs text-zinc-400 leading-relaxed">
                        Regardless of LBW predictions, if the batsman hits the ball into the neighbor&apos;s flower pots, balconies, or roof tiles, they are immediately declared OUT, and they must go negotiate with the uncle/aunty to fetch the ball.
                      </p>
                    </div>

                    <div className="bg-zinc-900/40 border-2 border-zinc-800 p-5 rounded-2xl space-y-1.5">
                      <div className="text-xs font-mono font-black text-brand uppercase tracking-widest">Bylaw #3</div>
                      <h4 className="text-sm font-black text-zinc-100 uppercase tracking-tight family-display">Third Umpire tea Break Override</h4>
                      <p className="text-xs text-zinc-400 leading-relaxed">
                        The AI virtual commentator acts as the official village third umpire. If a batsman continues to argue once the AI displays &rdquo;OUT&rdquo;, they are penalized of having to buy samosas or tea for both teams at the local shop.
                      </p>
                    </div>

                    <div className="bg-zinc-900/40 border-2 border-zinc-800 p-5 rounded-2xl space-y-1.5">
                      <div className="text-xs font-mono font-black text-brand uppercase tracking-widest">Bylaw #4</div>
                      <h4 className="text-sm font-black text-zinc-100 uppercase tracking-tight family-display">Equipment Ownership Sovereignty</h4>
                      <p className="text-xs text-zinc-400 leading-relaxed">
                        If the batsman is the absolute sole owner of the cricket leather bat or tape-ball, they retain a temporary veto power on umpire decisions. However, abusing this veto will result in public banishment from subsequent matches.
                      </p>
                    </div>
                  </div>

                  <p className="text-center text-xs font-mono text-zinc-500 pt-5">
                    Authorized and signed of accordance by the Gully Cricket Federation Councils.
                  </p>
                </div>
              </div>
            </div>
          )}
        </main>

        {/* Sticky footer credits */}
        <footer className="border-t border-zinc-900 pt-5 pb-2 text-center text-[10px] text-zinc-500 font-mono flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            © 2026 Gully Hawkeye systems. Built for resolving street LBW disputes fairly.
          </div>
          <div className="flex items-center space-x-1 text-emerald-500 font-semibold uppercase tracking-wider">
            <Volume2 className="w-3.5 h-3.5" />
            <span>Voice commentating authorized by Google Gemini API</span>
          </div>
        </footer>

      </div>
    </div>
  );
}
