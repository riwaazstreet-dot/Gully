/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { StumpCalibration, BallTrackingPoint, LBWDecision } from '../types';

export interface PhysicsTrajectoryPoint {
  x3d: number; // side-to-side meters (0 is center of pitch)
  y3d: number; // height meters above turf (0 is ground)
  z3d: number; // depth meters (2 is bowler release, 20 is stumps)
  x2d: number; // projected screen % (0 - 100)
  y2d: number; // projected screen % (0 - 100)
  time: number; // seconds from release
  isPredicted: boolean; // true if after impact point
}

/**
 * Reconstructs the 3D trajectory from 2D points and calibrates the LBW decision.
 */
export function calculateTrajectoryAndDecision(
  calibration: StumpCalibration,
  points: BallTrackingPoint[]
): {
  trajectory: PhysicsTrajectoryPoint[];
  decision: LBWDecision;
} {
  // Sort points by type/time progression to ensure proper solver ordering
  const pRelease = points.find(p => p.type === 'release');
  const pPitch = points.find(p => p.type === 'pitch');
  const pImpact = points.find(p => p.type === 'impact');

  // Ground rules variables if points are missing
  const releaseY2D = pRelease ? pRelease.y : 15;
  const releaseX2D = pRelease ? pRelease.x : 50;
  
  const pitchY2D = pPitch ? pPitch.y : 65;
  const pitchX2D = pPitch ? pPitch.x : 50;

  const impactY2D = pImpact ? pImpact.y : 75;
  const impactX2D = pImpact ? pImpact.x : 50;

  // Stumps parameters
  const stumpCenter2D = calibration.x; // e.g. 50%
  const stumpY2D = calibration.y; // ground line, e.g. 80%
  const stumpHeight2D = calibration.height; // e.g. 35% height
  const stumpWidth2D = calibration.width; // e.g. 15% width

  // Mapping depth Z:
  // We specify constant depth landmarks:
  const Z_RELEASE = 2.0;    // meters
  const Z_STUMPS = 20.0;    // meters
  
  // Calculate depth of pitch and impact based on Y coordinates
  // Lower on screen (higher Y) means closer to wickets (deeper Z)
  const ySpanMax = stumpY2D - releaseY2D;
  
  const getZFromY2D = (y2d: number) => {
    const fraction = (y2d - releaseY2D) / ySpanMax;
    // quadratic easing to simulate perspective foreshortening
    const t = Math.min(Math.max(fraction, 0), 1);
    const eased = t * t; // deep perspective compression
    return Z_RELEASE + eased * (Z_STUMPS - Z_RELEASE);
  };

  const Z_PITCH = getZFromY2D(pitchY2D);
  const Z_IMPACT = getZFromY2D(impactY2D);

  // Reconcile standard lateral X coordinates (0 as center line)
  // Wider perspective spread at larger Z depths.
  const getX3D = (x2d: number, z: number) => {
    // 50% is center line. Screen deviation is scaled down by depth perspective factor
    // At stumps (Z=20), 1% screen width is approx 0.05 meters. At release, it is less.
    const centerOffset = x2d - 50;
    const perspectiveFactor = 0.015 * (z + 4); // widening factor as depth increases
    return centerOffset * perspectiveFactor;
  };

  const X_RELEASE = getX3D(releaseX2D, Z_RELEASE);
  const X_PITCH = getX3D(pitchX2D, Z_PITCH);
  const X_IMPACT = getX3D(impactX2D, Z_IMPACT);

  // Time parameters (assumed speed of village deliveries: around 70-100 km/h)
  const averageVelocityZ = 22.0; // ~80 km/h in meters/sec
  const t_pitch = (Z_PITCH - Z_RELEASE) / averageVelocityZ;
  const t_impact = (Z_IMPACT - Z_RELEASE) / averageVelocityZ;

  // Horizontal lateral speed
  const vx_pre = (X_PITCH - X_RELEASE) / t_pitch;
  const vx_post = (X_IMPACT - X_PITCH) / (t_impact - t_pitch);

  // Vertical movement heights (Y 3D)
  // Bowler release height (approx 2.1 meters)
  const H_RELEASE = 2.1;
  // Bounces on dirt (0 meters height)
  const H_PITCH = 0.05; // tiny clearance
  
  // Solves for pre-bounce parabola: h(t) = a*t^2 + b*t + c
  // Since we have h(0) = H_RELEASE, h(t_pitch) = H_PITCH, and we assume gravity = 9.8 m/s^2,
  // we can reconstruct the trajectory:
  // h(t) = H_RELEASE + vy_release*t - 0.5 * 9.8 * t^2
  const vy_release = (H_PITCH - H_RELEASE + 0.5 * 9.8 * t_pitch * t_pitch) / t_pitch;

  // Bounce simulation: Coefficient of restitution e
  const vy_touch = vy_release - 9.8 * t_pitch; // velocity just before landing
  const restitution = 0.65; // standard village pitch bounce
  const vy_rebound = -vy_touch * restitution; // upward velocity after bounce

  // Generate continuous points (60 points total along the pitch)
  const totalDuration = (Z_STUMPS - Z_RELEASE) / averageVelocityZ;
  const numSteps = 80;
  const trajectory: PhysicsTrajectoryPoint[] = [];

  // Helper to project 3D coordinates back onto 2D screen
  const projectTo2D = (x3d: number, y3d: number, z3d: number) => {
    // Inverse perspective equations
    const t = (z3d - Z_RELEASE) / (Z_STUMPS - Z_RELEASE);
    // Linear coordinates for layout placement mapping
    const y2d = releaseY2D + Math.sqrt(t) * ySpanMax;
    
    const perspectiveFactor = 0.015 * (z3d + 4);
    const x2d = 50 + x3d / perspectiveFactor;
    return { x2d, y2d };
  };

  for (let i = 0; i <= numSteps; i++) {
    const progress = i / numSteps;
    const t = progress * totalDuration;
    const z3d = Z_RELEASE + t * averageVelocityZ;

    let x3d = 0;
    let y3d = 0;
    const isPredicted = t > t_impact;

    // Horizontal track
    if (t <= t_pitch) {
      x3d = X_RELEASE + vx_pre * t;
    } else {
      x3d = X_PITCH + vx_post * (t - t_pitch);
    }

    // Vertical track
    if (t <= t_pitch) {
      y3d = H_RELEASE + vy_release * t - 0.5 * 9.8 * t * t;
      y3d = Math.max(y3d, 0);
    } else {
      const t_post = t - t_pitch;
      y3d = H_PITCH + vy_rebound * t_post - 0.5 * 9.8 * t_post * t_post;
      y3d = Math.max(y3d, 0);
    }

    const { x2d, y2d } = projectTo2D(x3d, y3d, z3d);

    trajectory.push({
      x3d,
      y3d,
      z3d,
      x2d,
      y2d,
      time: t,
      isPredicted
    });
  }

  // Calculate precise cross height and width exactly at the wickets depth (Z=20)
  const t_stumps = (Z_STUMPS - Z_RELEASE) / averageVelocityZ;
  let stumpsX3D = X_PITCH + vx_post * (t_stumps - t_pitch);
  const t_post_stumps = t_stumps - t_pitch;
  let stumpsY3D = H_PITCH + vy_rebound * t_post_stumps - 0.5 * 9.8 * t_post_stumps * t_post_stumps;
  stumpsY3D = Math.max(stumpsY3D, 0);

  // Pitch widths and stump heights in meters
  // Convert calibrated stump screen dimensions to meters
  const stumpHeightMeters = stumpHeight2D * 0.045; // custom scale: height in meters
  const stumpWidthMeters = stumpWidth2D * 0.08; // custom scale: width in meters

  // Stumps horizontal center coordinate in meters
  const stumpCenterMeters = getX3D(stumpCenter2D, Z_STUMPS);
  const stumpLeftMeters = stumpCenterMeters - stumpWidthMeters / 2;
  const stumpRightMeters = stumpCenterMeters + stumpWidthMeters / 2;

  // Pitching line assessment
  // Inside the crease: center of wickets width is usually 2.64 meters
  const pitchInMeters = getX3D(pitchX2D, Z_PITCH);
  let pitching: 'In Line' | 'Outside Off' | 'Outside Leg' | 'Not Pitched' = 'In Line';
  
  // Village right-handed batsman standard assumption.
  // Left side of visual screen is Off Side, right is Leg Side (standard behind wickets view)
  const offMargin = stumpLeftMeters - 0.5;
  const legMargin = stumpRightMeters + 0.5;

  if (pitchInMeters < offMargin) {
    pitching = 'Outside Off';
  } else if (pitchInMeters > legMargin) {
    pitching = 'Outside Leg';
  } else {
    pitching = 'In Line';
  }

  // Impact line assessment
  const impactInMeters = getX3D(impactX2D, Z_IMPACT);
  let impact: 'In Line' | 'Outside' | 'Missing Wickets' = 'In Line';
  if (impactInMeters < stumpLeftMeters || impactInMeters > stumpRightMeters) {
    impact = 'Outside';
  }

  // Check if ball hits wickets
  const hitWidth = stumpsX3D >= stumpLeftMeters && stumpsX3D <= stumpRightMeters;
  const hitHeight = stumpsY3D >= 0 && stumpsY3D <= stumpHeightMeters;
  const wickets = (hitWidth && hitHeight) ? 'Hitting' : 'Missing';

  // Final LBW Verdict decision logic mapping:
  // Standard ICC and Street Rules combo:
  // 1. If it pitched outside leg-stump -> NOT OUT (Absolute village rule! You can never be out if it pitched outside leg)
  // 2. If impact is outside off-stump and the batsman was playing a genuine stroke -> usually NOT OUT, but if they pad away then OUT. In village we assume NOT OUT if impact is outside!
  // 3. Otherwise, if it is Hitting -> OUT!
  let decision: 'OUT' | 'NOT OUT' = 'NOT OUT';
  let summary = '';

  if (pitching === 'Outside Leg') {
    decision = 'NOT OUT';
    summary = 'Not Out! Ball pitched outside leg stump. Instant safety!';
  } else if (impact === 'Outside') {
    decision = 'NOT OUT';
    summary = `Not Out! Impact with pad was outside the stump lines. Suresh is shouting, but Ramesh is safe.`;
  } else if (wickets === 'Missing') {
    decision = 'NOT OUT';
    if (stumpsY3D > stumpHeightMeters) {
      summary = `Not Out! Ball went over the ${calibration.height > 30 ? 'custom stumps' : 'stumps'}. Missing high!`;
    } else {
      summary = 'Not Out! The ball went wide of the stumps.';
    }
  } else {
    decision = 'OUT';
    summary = `OUT! Trapped squarely in front. Pitched In-Line, Impact In-Line, and Hitting the stumps!`;
  }

  return {
    trajectory,
    decision: {
      pitching,
      impact,
      wickets,
      decision,
      summary,
      details: {
        pitchingLine: pitching,
        impactLine: impact,
        wicketContact: wickets === 'Hitting' ? 'Crashed Plumb' : stumpsY3D > stumpHeightMeters ? 'Over the Top' : 'Spun Wide',
        ballHeightAtWickets: stumpsY3D,
        stumpTopHeight: stumpHeightMeters
      }
    }
  };
}
