/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DeliverySample } from '../types';

export const VILLAGE_SAMPLES: DeliverySample[] = [
  {
    id: 'sample_bricks_yorker',
    name: 'The Plumb Yorker (Pile of Bricks)',
    description: 'Suresh bowls a roaring yorker directly down the middle, trapping Ramesh who claims it was going over.',
    stumpType: 'Pile of Bricks',
    narrative: 'A heavy, dangerous delivery aimed at the bottom red brick. Zero turn, pure pace!',
    defaultCalibration: {
      x: 50,
      y: 80,
      width: 14,
      height: 38,
      tilt: 2,
    },
    defaultTrackingPoints: [
      { id: 'p1', x: 48, y: 15, frameIndex: 5, type: 'release', label: 'Release' },
      { id: 'p2', x: 49.5, y: 72, frameIndex: 18, type: 'pitch', label: 'Pitching' },
      { id: 'p3', x: 50, y: 76, frameIndex: 22, type: 'impact', label: 'Impact (Pad)' },
    ]
  },
  {
    id: 'sample_chair_turner',
    name: ' Shane Warne of the Village (Wooden Chair)',
    description: 'Dinesh bowls a massive off-break that spins sharply. Mukesh is hit on his slippers but claims it spun way down leg side.',
    stumpType: 'Wooden Chair',
    narrative: 'Pitches wide outside off-stump on a loose stone and turns like a cycle tyre past the batsman.',
    defaultCalibration: {
      x: 50,
      y: 80,
      width: 18,
      height: 40,
      tilt: -1,
    },
    defaultTrackingPoints: [
      { id: 'p1', x: 38, y: 16, frameIndex: 5, type: 'release', label: 'Release' },
      { id: 'p2', x: 58, y: 64, frameIndex: 20, type: 'pitch', label: 'Pitching' },
      { id: 'p3', x: 42, y: 74, frameIndex: 26, type: 'impact', label: 'Impact (Slipper)' },
    ]
  },
  {
    id: 'sample_water_jug_bouncer',
    name: 'The High Bouncer (Blue Water Drum)',
    description: 'Anish bowls a fast bouncer hitting Umesh high up on the shorts. Bowler celebrates like crazy; batsman says it is a wide bouncer.',
    stumpType: 'Blue Water Drum',
    narrative: 'A short pitch delivery that kicks up off a patch of wild grass and sails over the wickets.',
    defaultCalibration: {
      x: 50,
      y: 82,
      width: 16,
      height: 36,
      tilt: 0,
    },
    defaultTrackingPoints: [
      { id: 'p1', x: 49, y: 12, frameIndex: 4, type: 'release', label: 'Release' },
      { id: 'p2', x: 49.5, y: 55, frameIndex: 14, type: 'pitch', label: 'Pitching' },
      { id: 'p3', x: 50, y: 44, frameIndex: 23, type: 'impact', label: 'Impact (Hip)' },
    ]
  },
  {
    id: 'sample_stick_swing',
    name: 'The Inswinger (Single Wooden Stick)',
    description: 'Mahesh bowls an inswinging full toss. Ganesh plays all around it and is struck on the thigh. He insists it pitched outside leg.',
    stumpType: 'Single Stuck Stick',
    narrative: 'A swinging full toss that curves through the air from outside off-stump directly into the single stick.',
    defaultCalibration: {
      x: 50,
      y: 78,
      width: 10,
      height: 44,
      tilt: 4,
    },
    defaultTrackingPoints: [
      { id: 'p1', x: 65, y: 14, frameIndex: 6, type: 'release', label: 'Release' },
      { id: 'p2', x: 56, y: 74, frameIndex: 21, type: 'pitch', label: 'Pitching' }, // actually doesn't bounce in a full toss, but we'll mark impact
      { id: 'p3', x: 51, y: 72, frameIndex: 25, type: 'impact', label: 'Impact (Thigh)' },
    ]
  }
];
